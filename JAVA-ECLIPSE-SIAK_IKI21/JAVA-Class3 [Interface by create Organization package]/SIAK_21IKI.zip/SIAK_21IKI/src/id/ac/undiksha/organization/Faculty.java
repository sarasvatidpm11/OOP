package id.ac.undiksha.organization;

public interface Faculty {
	public void setFacultyName(String facultyName);
	public String getFacultyName();
}