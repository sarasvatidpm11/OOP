package id.ac.undiksha.organization;

public interface Department {
	public void setDeptName(String deptName);
	public String getDeptName();
	
	public void setDeptCode(String deptCode);
	public String getDeptCode();
}