package id.ac.undiksha.siak.entities;

import id.ac.undiksha.organization.StudyProgram;

public class Student extends Person{ //extends = diperluas

	private String nim;
	private StudyProgram studyProgram;
	
	public Student() {
		super();
		this.nim			= "<invalid nim>";
		studyProgram = new StudyProgram();
	}
	
	// public Student(String nim, String name, String address, boolean gender, String studyProgramCode, String studyProgramName) {
	// 	super(name, address, gender);
	// 	this.nim = nim;
	// 	this.getStudyProgram, setStudyProgramCode(studyProgramCode);
	// }

	public void printAllInfo() {
		System.out.println("Student Identity");
		System.out.println("NIM: " + this.getNim());
		System.out.println("Name: " + this.getName());
		System.out.println("Address: " + this.getAddress());
		System.out.println("Gender: " + (getGender() ? "Male" : "Female"));
		System.out.println("Study Program Code: " + this.getStudyProgram().getStudyProgramCode());
		System.out.println("Study Program: " + this.getStudyProgram().getStudyProgramName());

		System.out.println("\nCoordinator Identity");
		System.out.println("Coordinator Name:  " + this.getStudyProgram().getCoordinator().getName());
		System.out.println("Coordinator Address: " + this.getStudyProgram().getCoordinator().getAddress());
		System.out.println("Coordinator NIP: " + this.getStudyProgram().getCoordinator().getNip());
		System.out.println("Gender: " + (this.getStudyProgram().getCoordinator().getGender() ? "Male" : "Female"));;
	}
	
	
	public Student(String name, String address, boolean gender, String nim, String studyProgramCode, String studyProgramName) {
		super(name, address, gender);
		this.nim 			= nim;
		studyProgram = new StudyProgram(studyProgramCode, studyProgramName);
	}
	
	public String getNim() {
		return nim;
	}

	public void setNim(String nim) {
		this.nim = nim;
	}

	public StudyProgram getStudyProgram() {
		return studyProgram;
	}

	public void setStudyProgram(StudyProgram studyProgram) {
		this.studyProgram = studyProgram;
	}
}
